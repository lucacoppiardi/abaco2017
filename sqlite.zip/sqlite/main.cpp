#include <iostream>
using namespace std;
#include <sqlite3.h>

int main(int argc, char **argv)
{
	
	sqlite3 *database;
	if (sqlite3_open("database.sqlite", &database) == SQLITE_OK) {
		cout << "Database aperto" << endl;
	} else {
		cout << "Errore nell'apertura del database" << endl;
	}
	
	sqlite3_stmt *statement;
	if(sqlite3_prepare_v2(database, "CREATE TABLE PERSONE (ID_PERSONA INTEGER, NOME STRING, COGNOME STRING);", -1, &statement, 0) == SQLITE_OK) {
		cout << "Tabella creata" << endl;
	} else {
		cout << "Errore nella creazione della tabella" << endl;
	}
	
	return 0;
}
