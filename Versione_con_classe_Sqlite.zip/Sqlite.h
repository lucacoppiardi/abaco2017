#ifndef SQLITE_H
#define SQLITE_H
#include <sqlite3.h>
class Sqlite{
public:
    char *zErrMsg = 0;
	int rc; // return code
	sqlite3 *database;
	const char *comando;
	sqlite3_stmt *stmt;	
		const char *pzTest;
	/*void Prepare(sqlite3 *database, char*comando, sqlite3_stmt *stmt, char*  pzTest);
	void Bind_Int(sqlite3_stmt *stmt, int index,int data);		
	void Bind_Text(sqlite3_stmt *stmt, int index,char *data);
	void Step(sqlite3_stmt *stmt);
	void Finalize(sqlite3_stmt *stmt);
	void Free(char *zErrMsg);
	void Open(char* nome, sqlite3 *database);
	sqlite3_exec(database, comando, callback, 0, &zErrMsg);
	 * */
};

#endif
