#ifndef PERSONA_H
#define PERSONA_H
#include <Sqlite.h>
using namespace std;

class Persona{
	private:
			int ID_PERSONA;
			string NOME;
			string COGNOME;
public:
			Sqlite s;
			Persona(){}
			Persona(int ID_PERSONA,string  NOME,string COGNOME);
			void assegnaSqlite(Sqlite &s1){s=s1;}
			void setCognome(const string& COGNOME) {this->COGNOME = COGNOME;}
			void setID_PERSONA(int ID_PERSONA) {this->ID_PERSONA = ID_PERSONA;}
			void setNome(const string& NOME) {this->NOME = NOME;}
			const string& getCognome() const {return COGNOME;}
			int getID_PERSONA() const {return ID_PERSONA;}
			const string& getNome() const {return NOME;}
			void stampa();
			void aggiungi_persona(); 
			void modifica_persona();
			void cancella_persona();
			int callback(void *NotUsed, int argc, char **argv, char **azColName) ;
};

#endif